<?php
/**
 * Run once: http://localhost/school-backend/database/fix_passwords.php
 * Deletes and re-inserts admin + student with correct password hashes.
 */
require_once __DIR__ . '/../config/db.php';

$db = getDB();

$users = [
    ['Admin User',   'admin@school.edu',   'admin123',   'admin'],
    ['John Student', 'student@school.edu', 'student123', 'student'],
];

// Delete existing demo users first
$db->query("DELETE FROM users WHERE email IN ('admin@school.edu','student@school.edu')");
echo "🗑️  Removed old demo users.<br>";

foreach ($users as [$name, $email, $password, $role]) {
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $db->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('ssss', $name, $email, $hash, $role);
    if ($stmt->execute()) {
        echo "✅ Inserted: <strong>$email</strong> / <strong>$password</strong> (role: $role)<br>";
    } else {
        echo "❌ Failed: $email — " . $stmt->error . "<br>";
    }
    $stmt->close();
}

$db->close();
echo "<br><strong>✅ Done! You can now login.</strong><br>";
echo "<a href='http://localhost:5173/login'>→ Go to Login</a>";
